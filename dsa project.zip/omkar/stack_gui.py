import tkinter as tk
from tkinter import messagebox

class ArrayStack:

    def __init__(self):
        self.stack = []

    def __len__(self):
        return len(self.stack)

    def is_empty(self):
        return len(self.stack) == 0

    def push(self, e):
        self.stack.append(e)

    def peek(self):
        if self.is_empty():
            raise Empty('Stack Underflow') # type: ignore
        else:
            return self.stack[-1]

    def pop(self):
        if self.is_empty():
            raise Empty('Stack Underflow') # type: ignore
        else:
            return self.stack.pop()

    def __str__(self):
        if self.is_empty():
            return "Stack is empty"
        else:
            return " top -> " + ", ".join(str(x) for x in self.stack[::-1]) + " <- bottom"

class StackGUI:
    def __init__(self, root):
        self.stack = ArrayStack()
        self.root = root
        self.root.title("ArrayStack GUI")

        self.input_label = tk.Label(root, text="Enter element:")
        self.input_label.pack()

        self.input_entry = tk.Entry(root)
        self.input_entry.pack()

        self.push_button = tk.Button(root, text="Push", command=self.push)
        self.push_button.pack()

        self.pop_button = tk.Button(root, text="Pop", command=self.pop)
        self.pop_button.pack()

        self.peek_button = tk.Button(root, text="Peek", command=self.peek)
        self.peek_button.pack()

        self.display_label = tk.Label(root, text="Stack: " + str(self.stack))
        self.display_label.pack()

    def push(self):
        element = self.input_entry.get()
        if element:
            self.stack.push(element)
            self.update_display()
            self.input_entry.delete(0, tk.END)

    def pop(self):
        try:
            popped_element = self.stack.pop()
            messagebox.showinfo("Popped", f"Popped element: {popped_element}")
            self.update_display()
        except Empty as e: # type: ignore
            messagebox.showerror("Error", str(e))

    def peek(self):
        try:
            top_element = self.stack.peek()
            messagebox.showinfo("Peek", f"Top element: {top_element}")
        except Empty as e: # type: ignore
            messagebox.showerror("Error", str(e))

    def update_display(self):
        self.display_label.config(text="Stack: " + str(self.stack))

if __name__ == "__main__":
    root = tk.Tk()
    gui = StackGUI(root)
    root.mainloop()
