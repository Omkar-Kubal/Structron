#heapq with GUI

import heapq
import tkinter as tk
from tkinter import messagebox

class PriorityQueue:

    def __init__(self):
        self.items = []

    def isEmpty(self):
        return len(self.items) == 0

    def enqueue(self, item, priority):
        heapq.heappush(self.items, (priority, item))  # store priority and item as a tuple

    def dequeue(self):
        if self.isEmpty():
            return None
        return heapq.heappop(self.items)[1]  # return only the element from the tuple

    def peek(self):
        if self.isEmpty():
            return None
        return heapq.nsmallest(1, self.items)[0][1]  # get smallest element (highest priority)

    def size(self):
        return len(self.items)

    def traverse(self):
        return [item for _, item in sorted(self.items, key=lambda x: x[0])]  # sorted by priority

class PriorityQueueApp:
    def __init__(self, root):
        self.queue = PriorityQueue()

        self.root = root
        self.root.title("Heap Priority Queue GUI")

        self.label = tk.Label(root, text="Omkar Kubal S088")
        self.label.pack()

        self.label = tk.Label(root, text="Heap Priority Queue", font=("Helvetica", 16))
        self.label.pack(pady=10)

        self.queue_display = tk.Label(root, text=self.queue_traversal(), font=("Helvetica", 12))
        self.queue_display.pack(pady=10)

        self.priority_entry = tk.Entry(root, font=("Helvetica", 12))
        self.priority_entry.pack(pady=5)
        self.priority_entry.insert(0, "Priority")

        self.element_entry = tk.Entry(root, font=("Helvetica", 12))
        self.element_entry.pack(pady=5)
        self.element_entry.insert(0, "Element")

        self.enqueue_button = tk.Button(root, text="Enqueue", command=self.enqueue)
        self.enqueue_button.pack(pady=5)

        self.dequeue_button = tk.Button(root, text="Dequeue", command=self.dequeue)
        self.dequeue_button.pack(pady=5)

        self.peek_button = tk.Button(root, text="Peek", command=self.peek)
        self.peek_button.pack(pady=5)

    def update_display(self):
        self.queue_display.config(text=self.queue_traversal())

    def queue_traversal(self):
        elements = self.queue.traverse()
        return "Priority Queue elements: " + ", ".join(elements) if elements else "Priority Queue is empty"

    def enqueue(self):
        try:
            priority = int(self.priority_entry.get())
            element = self.element_entry.get()
            if element:
                self.queue.enqueue(element, priority)
                self.priority_entry.delete(0, tk.END)
                self.element_entry.delete(0, tk.END)
                self.update_display()
            else:
                messagebox.showwarning("Input Error", "Please enter an element to enqueue.")
        except ValueError:
            messagebox.showwarning("Input Error", "Please enter a valid priority.")

    def dequeue(self):
        element = self.queue.dequeue()
        if element:
            messagebox.showinfo("Dequeued Element", f"Dequeued: {element}")
            self.update_display()
        else:
            messagebox.showerror("Queue Underflow", "Priority Queue is empty. Cannot dequeue.")

    def peek(self):
        element = self.queue.peek()
        if element:
            messagebox.showinfo("Peek Element", f"Front element: {element}")
        else:
            messagebox.showerror("Queue Underflow", "Priority Queue is empty. Cannot peek.")

# Main function to run the GUI application
if __name__ == "__main__":
    root = tk.Tk() 
    app = PriorityQueueApp(root)
    root.mainloop()
