import matplotlib.pyplot as plt
import networkx as nx
import tkinter as tk
from tkinter import messagebox
from collections import defaultdict
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


class Graph:
    def __init__(self):
        self.graph = defaultdict(list)

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            self.graph[vertex2].append(vertex1)

    def dfs_tree(self, start):
        """Perform DFS and return the Depth-First Tree as a dictionary."""
        visited = set()
        dfs_tree = defaultdict(list)
        
        def dfs(vertex):
            visited.add(vertex)
            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    dfs_tree[vertex].append(neighbor)
                    dfs(neighbor)
        
        dfs(start)
        return dfs_tree

    def visualize(self, dfs_tree=None):
        """Visualize the graph and optionally the DFS tree."""
        G = nx.Graph(self.graph)
        pos = nx.spring_layout(G)
        fig, ax = plt.subplots(1, 2, figsize=(12, 6))

        # Draw the original graph
        nx.draw(G, pos, with_labels=True, node_color='lightblue', edge_color='gray',
                node_size=800, font_size=12, font_weight='bold', ax=ax[0])
        ax[0].set_title("Graph")

        # Draw the DFS Tree if present
        if dfs_tree:
            T = nx.DiGraph(dfs_tree)
            pos_tree = nx.spring_layout(T)
            nx.draw(T, pos_tree, with_labels=True, node_color='lightgreen', edge_color='blue',
                    node_size=800, font_size=12, font_weight='bold', arrows=True, ax=ax[1])
            ax[1].set_title("DFS Tree")
        
        return fig


class GraphApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Graph DFS Visualization")
        self.root.geometry("900x700")
        self.root.configure(bg="lightgray")
        self.graph = Graph()

        # Roll number and name at the top
        self.info_label = tk.Label(root, text="S088 Omkar Kubal", font=("Helvetica", 12))
        self.info_label.grid(row=0, column=0, columnspan=5, pady=10)

        # Title
        self.title_label = tk.Label(root, text="Graph DFS Visualization", font=("Helvetica", 18, "bold"))
        self.title_label.grid(row=1, column=0, columnspan=5, pady=10)

        # Vertex and Edge Entry
        self.vertex_label = tk.Label(root, text="Vertex:", font=("Helvetica", 14))
        self.vertex_label.grid(row=2, column=0, columnspan=1)
        self.vertex_entry = tk.Entry(root, font=("Helvetica", 14), width=10)
        self.vertex_entry.grid(row=2, column=1, columnspan=1)
        self.add_vertex_button = tk.Button(root, text="Add Vertex", font=("Helvetica", 14), width=12, command=self.add_vertex)
        self.add_vertex_button.grid(row=2, column=4, columnspan=1)

        self.edge_label = tk.Label(root, text="Edge (vertex1 vertex2):", font=("Helvetica", 14))
        self.edge_label.grid(row=3, column=0, columnspan=1)
        self.edge_entry = tk.Entry(root, font=("Helvetica", 14), width=10)
        self.edge_entry.grid(row=3, column=1, columnspan=1)
        self.add_edge_button = tk.Button(root, text="Add Edge", font=("Helvetica", 14), width=12, command=self.add_edge)
        self.add_edge_button.grid(row=3, column=4, columnspan=1)

        # Start DFS Entry
        self.dfs_label = tk.Label(root, text="Start Vertex for DFS:", font=("Helvetica", 14))
        self.dfs_label.grid(row=4, column=0)
        self.dfs_entry = tk.Entry(root, font=("Helvetica", 14), width=10)
        self.dfs_entry.grid(row=4, column=1)
        self.dfs_button = tk.Button(root, text="Perform DFS", font=("Helvetica", 14), width=12, command=self.perform_dfs)
        self.dfs_button.grid(row=4, column=4, columnspan=1)

        self.display_button = tk.Button(root, text="Display Graph", font=("Helvetica", 14), width=16, command=self.display_graph)
        self.display_button.grid(row=6, column=4)

        # Canvas for matplotlib graph visualization
        self.canvas_frame = tk.Frame(root)
        self.canvas_frame.grid(row=7, column=0, columnspan=5, pady=10)

    def add_vertex(self):
        vertex = self.vertex_entry.get()
        if vertex:
            self.graph.add_vertex(vertex)
            self.vertex_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Input Error", "Please enter a valid vertex.")

    def add_edge(self):
        edge = self.edge_entry.get().split()
        if len(edge) == 2:
            vertex1, vertex2 = edge
            self.graph.add_edge(vertex1, vertex2)
            self.edge_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Input Error", "Please enter two valid vertices.")

    def perform_dfs(self):
        start_vertex = self.dfs_entry.get()
        if start_vertex:
            dfs_tree = self.graph.dfs_tree(start_vertex)
            self.display_graph(dfs_tree)
        else:
            messagebox.showwarning("Input Error", "Please enter a start vertex for DFS.")

    def display_graph(self, dfs_tree=None):
        """Display the graph and DFS tree in the GUI using matplotlib."""
        fig = self.graph.visualize(dfs_tree)

        # Clear the old plot if it exists
        for widget in self.canvas_frame.winfo_children():
            widget.destroy()

        canvas = FigureCanvasTkAgg(fig, master=self.canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack()


# Run the application
if __name__ == "__main__":
    root = tk.Tk()
    app = GraphApp(root)
    root.mainloop()
