import subprocess
from flask import Flask, render_template
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/stack')
def stack():
    # Add your stack GUI logic here, if necessary
    return render_template('stack.html')

@app.route('/queue')
def queue():
    # Add your queue GUI logic here, if necessary
    return render_template('queue.html')

@app.route('/priority_queue')
def priority_queue():
    # Add your priority queue GUI logic here, if necessary
    return render_template('priority_queue.html')

@app.route('/heapq')
def heapq():
    # Add your heapq GUI logic here, if necessary
    return render_template('heapq.html')

@app.route('/linked_list')
def linked_list():
    # Add your linked list GUI logic here, if necessary
    return render_template('linked_list.html')

@app.route('/doubly_linked_list')
def doubly_linked_list():
    # Add your doubly linked list GUI logic here, if necessary
    return render_template('doubly_linked_list.html')

@app.route('/binary_tree')
def binary_tree():
    # Add your binary tree GUI logic here, if necessary
    return render_template('binary_tree.html')

@app.route('/huffman')
def huffman():
    # Add your Huffman tree GUI logic here, if necessary
    return render_template('huffman.html')

@app.route('/bfs')
def bfs():
    # Add your BFS logic here, if necessary
    return render_template('bfs.html')

@app.route('/dfs')
def dfs():
    # Add your DFS logic here, if necessary
    return render_template('dfs.html')

@app.route('/tsp')
def tsp():
    # Add your TSP logic here, if necessary
    return render_template('tsp.html')

@app.route('/hashing')
def hashing():
    # Add your hashing logic here, if necessary
    return render_template('hashing.html')
@app.route('/stack_gui')
def run_stack_gui():
    subprocess.Popen(['python', 'stack_gui.py']) 
    return "Stack GUI is running!"
@app.route('/queue_gui')
def run_queue_gui():
    subprocess.Popen(['python', 'queue_gui.py']) 
    return "Stack GUI is running!"
@app.route('/priority_gui')
def run_priority_gui():
    subprocess.Popen(['python', 'priority_gui.py']) 
    return "Stack GUI is running!"

if __name__ == "__main__":
    app.run(debug=True)

