import tkinter as tk
from tkinter import messagebox
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class Graph:
    def __init__(self):
        self.graph = {}

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            del self.graph[vertex]
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

    def add_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            self.graph[vertex2].append(vertex1)

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].remove(vertex2)
            self.graph[vertex2].remove(vertex1)

    def display(self):
        return self.graph

class GraphGUI:
    def __init__(self):
        self.graph = Graph()
        self.window = tk.Tk()
        self.window.title("Graph GUI")
        self.label = tk.Label(self.window, text="Omkar Kubal S088")
        self.label.pack()

        self.vertex_entry = tk.Entry(self.window)
        self.vertex_entry.pack()
        self.add_vertex_button = tk.Button(self.window, text="Add Vertex", command=self.add_vertex)
        self.add_vertex_button.pack()

        self.edge_entry = tk.Entry(self.window)
        self.edge_entry.pack()
        self.add_edge_button = tk.Button(self.window, text="Add Edge", command=self.add_edge)
        self.add_edge_button.pack()

        self.remove_vertex_entry = tk.Entry(self.window)
        self.remove_vertex_entry.pack()
        self.remove_vertex_button = tk.Button(self.window, text="Remove Vertex", command=self.remove_vertex)
        self.remove_vertex_button.pack()

        self.remove_edge_entry = tk.Entry(self.window)
        self.remove_edge_button = tk.Button(self.window, text="Remove Edge", command=self.remove_edge)
        self.remove_edge_button.pack()

        self.display_button = tk.Button(self.window, text="Display Graph", command=self.display_graph)
        self.display_button.pack()

        self.fig = plt.figure(figsize=(5, 4))
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.window)
        self.canvas.get_tk_widget().pack()

    def add_vertex(self):
        vertex = self.vertex_entry.get()
        self.graph.add_vertex(vertex)
        self.vertex_entry.delete(0, tk.END)
        self.display_graph()

    def add_edge(self):
        edge = self.edge_entry.get().split()
        if len(edge) == 2:
            vertex1, vertex2 = edge
            self.graph.add_edge(vertex1, vertex2)
            self.edge_entry.delete(0, tk.END)
            self.display_graph()

    def remove_vertex(self):
        vertex = self.remove_vertex_entry.get()
        self.graph.remove_vertex(vertex)
        self.remove_vertex_entry.delete(0, tk.END)
        self.display_graph()

    def remove_edge(self):
        edge = self.remove_edge_entry.get().split()
        if len(edge) == 2:
            vertex1, vertex2 = edge
            self.graph.remove_edge(vertex1, vertex2)
            self.remove_edge_entry.delete(0, tk.END)
            self.display_graph()

    def display_graph(self):
        plt.clf()
        graph = self.graph.display()

        # Create a new networkx graph object
        G = nx.Graph()

        # Add vertices to the graph (including isolated ones)
        for vertex in graph:
            G.add_node(vertex)
            for neighbor in graph[vertex]:
                G.add_edge(vertex, neighbor)

        # Create positions for nodes and draw the graph
        pos = nx.spring_layout(G)
        nx.draw(G, pos, with_labels=True, node_size=500, node_color='lightblue', font_size=12, font_weight='bold')

        self.canvas.draw()

    def run(self):
        self.window.mainloop()

if __name__ == "__main__":
    gui = GraphGUI()
    gui.run()
