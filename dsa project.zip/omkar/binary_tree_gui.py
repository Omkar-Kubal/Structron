import tkinter as tk
from tkinter import messagebox

class Node:
    def __init__(self, key):
        self.left = None
        self.right = None
        self.val = key

class BinaryTree:
    def __init__(self):
        self.root = None

    def insert(self, key):
        if self.root is None:
            self.root = Node(key)
        else:
            self._insert(self.root, key)
            
    def _insert(self, root, key):
        if key < root.val:
            if root.left is None:
                root.left = Node(key)
            else:
                self._insert(root.left, key)
        else:
            if root.right is None:
                root.right = Node(key)
            else:
                self._insert(root.right, key)

    def delete(self, key):
        self.root = self._delete(self.root, key)

    def _delete(self, root, key):
        if root is None:
            return root
        if key < root.val:
            root.left = self._delete(root.left, key)
        elif key > root.val:
            root.right = self._delete(root.right, key)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            min_larger_node = self._get_min(root.right)
            root.val = min_larger_node.val
            root.right = self._delete(root.right, min_larger_node.val)
        return root

    def _get_min(self, node):
        current = node
        while current.left is not None:
            current = current.left
        return current

    def inorder_traversal(self):
        return self._inorder_traversal(self.root)

    def _inorder_traversal(self, root):
        res = []
        if root:
            res = self._inorder_traversal(root.left)
            res.append(root.val)
            res = res + self._inorder_traversal(root.right)
        return res

class BinaryTreeGUI:
    def __init__(self, root):
        self.tree = BinaryTree()
        self.root = root
        self.root.title("Binary Tree GUI - Omkar Kubal S088")

        self.label = tk.Label(root, text="Omkar Kubal S088")
        self.label.pack()
        
        self.canvas = tk.Canvas(root, width=600, height=400, bg='white')
        self.canvas.pack()

        self.label = tk.Label(root, text="Enter a value:")
        self.label.pack()

        self.entry = tk.Entry(root)
        self.entry.pack()

        self.insert_button = tk.Button(root, text="Insert", command=self.insert_value)
        self.insert_button.pack()

        self.delete_button = tk.Button(root, text="Delete", command=self.delete_value)
        self.delete_button.pack()

        self.clear_button = tk.Button(root, text="Clear Tree", command=self.clear_tree)
        self.clear_button.pack()

    def insert_value(self):
        value = self.entry.get()
        if value.isdigit():
            self.tree.insert(int(value))
            self.update_canvas()
            self.entry.delete(0, tk.END)
        else:
            messagebox.showerror("Invalid Input", "Please enter a valid integer.")

    def delete_value(self):
        value = self.entry.get()
        if value.isdigit():
            self.tree.delete(int(value))
            self.update_canvas()
            self.entry.delete(0, tk.END)
        else:
            messagebox.showerror("Invalid Input", "Please enter a valid integer.")

    def clear_tree(self):
        self.tree = BinaryTree()
        self.update_canvas()

    def update_canvas(self):
        self.canvas.delete("all")
        if self.tree.root is not None:
            self._draw_node(self.tree.root, 300, 50, 150)

    def _draw_node(self, node, x, y, offset):
        if node is not None:
            self.canvas.create_oval(x-15, y-15, x+15, y+15, fill="lightblue")
            self.canvas.create_text(x, y, text=str(node.val), font=("Arial", 12, "bold"))
            if node.left:
                self.canvas.create_line(x, y+15, x-offset, y+75-15, fill="black")
                self._draw_node(node.left, x-offset, y+75, offset//2)
            if node.right:
                self.canvas.create_line(x, y+15, x+offset, y+75-15, fill="black")
                self._draw_node(node.right, x+offset, y+75, offset//2)

if __name__ == "__main__":
    root = tk.Tk()
    gui = BinaryTreeGUI(root)
    root.mainloop()
