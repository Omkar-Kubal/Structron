import tkinter as tk
from tkinter import messagebox

class LinkedStack:
    class Node:
        __slots__ = 'element', 'next'

        def __init__(self, element, next):
            self.element = element
            self.next = next
            
    def __init__(self):
        self.head = None
        self.size = 0

    def __len__(self):
        return self.size

    def is_empty(self):
        return self.size == 0

    def push(self, e):
        self.head = self.Node(e, self.head)
        self.size += 1

    def peek(self):
        if self.is_empty():
            raise Empty('Stack is empty!')
        else:
            return self.head.element # type: ignore
        
    def pop(self):
        if self.is_empty():
            raise Empty('Stack is empty!')
        else:
            answer = self.head.element # type: ignore
            self.head = self.head.next # type: ignore
            self.size -= 1
            return answer

    def __str__(self):
        result = []
        current = self.head
        while current is not None:
            result.append(current.element)
            current = current.next
        return ' -> '.join(map(str, result))


class Empty(Exception):
    pass


class StackGUI:
    def __init__(self, root):
        self.stack = LinkedStack()
        
        self.root = root
        self.root.title("Stack GUI")
        
        self.frame = tk.Frame(root)
        self.frame.pack(padx=10, pady=10)
        
        self.label = tk.Label(self.frame, text="Enter element to push:")
        self.label.grid(row=0, column=0, pady=5)
        
        self.entry = tk.Entry(self.frame)
        self.entry.grid(row=0, column=1, pady=5)
        
        self.push_button = tk.Button(self.frame, text="Push", command=self.push)
        self.push_button.grid(row=0, column=2, padx=5, pady=5)
        
        self.pop_button = tk.Button(self.frame, text="Pop", command=self.pop)
        self.pop_button.grid(row=1, column=0, padx=5, pady=5)
        
        self.peek_button = tk.Button(self.frame, text="Peek", command=self.peek)
        self.peek_button.grid(row=1, column=1, padx=5, pady=5)
        
        self.display_label = tk.Label(self.frame, text="Stack elements:")
        self.display_label.grid(row=2, column=0, pady=10)
        
        self.stack_display = tk.Label(self.frame, text="", relief="sunken", width=50, anchor="w")
        self.stack_display.grid(row=2, column=1, columnspan=2, pady=10)
        
        self.update_display()
        
    def push(self):
        element = self.entry.get()
        if element:
            self.stack.push(element)
            self.entry.delete(0, tk.END)
            self.update_display()
        else:
            messagebox.showwarning("Input Error", "Please enter an element to push.")
        
    def pop(self):
        try:
            popped_element = self.stack.pop()
            messagebox.showinfo("Pop", f"Popped element: {popped_element}")
            self.update_display()
        except Empty as e:
            messagebox.showerror("Stack Error", str(e))
        
    def peek(self):
        try:
            top_element = self.stack.peek()
            messagebox.showinfo("Peek", f"Top element: {top_element}")
        except Empty as e:
            messagebox.showerror("Stack Error", str(e))
        
    def update_display(self):
        self.stack_display.config(text=str(self.stack))


if __name__ == "__main__":
    root = tk.Tk()
    app = StackGUI(root)
    root.mainloop()
