#Priority Queue with Gui

import tkinter as tk
from tkinter import messagebox

class PriorityQueue:
    def __init__(self):
        self.data = []

    def __len__(self):
        return len(self.data)

    def is_empty(self):
        return len(self.data) == 0

    def enqueue(self, priority, e):
        self.data.append((priority, e))
        self.data.sort(key=lambda x: x[0])  # Sort by priority

    def dequeue(self):
        if self.is_empty():
            raise Exception('Queue Underflow')
        return self.data.pop(0)[1]  # Remove the element with the highest priority (lowest priority number)

    def peek(self):
        if self.is_empty():
            raise Exception('Queue Underflow')
        return self.data[0][1]  # Peek the element with the highest priority (lowest priority number)

    def __str__(self):
        if self.is_empty():
            return "Priority Queue is empty"
        result = []
        for priority, element in self.data:
            result.append(f"({priority}, {element})")
        return " front -> " + ", ".join(result) + " <- rear"

# GUI Application
class PriorityQueueApp:
    def __init__(self, root):
        self.queue = PriorityQueue()

        self.root = root
        self.root.title("PriorityQueue GUI")

        self.label = tk.Label(root, text="Omkar Kubal S088")
        self.label.pack()

        self.label = tk.Label(root, text="PriorityQueue", font=("Helvetica", 16))
        self.label.pack(pady=10)

        self.queue_display = tk.Label(root, text=str(self.queue), font=("Helvetica", 12))
        self.queue_display.pack(pady=10)

        self.priority_entry = tk.Entry(root, font=("Helvetica", 12))
        self.priority_entry.pack(pady=5)
        self.priority_entry.insert(0, "Priority")

        self.element_entry = tk.Entry(root, font=("Helvetica", 12))
        self.element_entry.pack(pady=5)
        self.element_entry.insert(0, "Element")

        self.enqueue_button = tk.Button(root, text="Enqueue", command=self.enqueue)
        self.enqueue_button.pack(pady=5)

        self.dequeue_button = tk.Button(root, text="Dequeue", command=self.dequeue)
        self.dequeue_button.pack(pady=5)

        self.peek_button = tk.Button(root, text="Peek", command=self.peek)
        self.peek_button.pack(pady=5)

    def update_display(self):
        self.queue_display.config(text=str(self.queue))

    def enqueue(self):
        try:
            priority = int(self.priority_entry.get())
            element = self.element_entry.get()
            if element:
                self.queue.enqueue(priority, element)
                self.priority_entry.delete(0, tk.END)
                self.element_entry.delete(0, tk.END)
                self.update_display()
            else:
                messagebox.showwarning("Input Error", "Please enter an element to enqueue.")
        except ValueError:
            messagebox.showwarning("Input Error", "Please enter a valid priority.")

    def dequeue(self):
        try:
            element = self.queue.dequeue()
            messagebox.showinfo("Dequeued Element", f"Dequeued: {element}")
            self.update_display()
        except Exception as e:
            messagebox.showerror("Queue Underflow", str(e))

    def peek(self):
        try:
            element = self.queue.peek()
            messagebox.showinfo("Peek Element", f"Front element: {element}")
        except Exception as e:
            messagebox.showerror("Queue Underflow", str(e))

# Main function to run the GUI application
if __name__ == "__main__":
    root = tk.Tk()
    app = PriorityQueueApp(root)
    root.mainloop()
