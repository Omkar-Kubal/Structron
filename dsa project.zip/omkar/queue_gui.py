# Queue with Gui

import tkinter as tk
from tkinter import messagebox

class ArrayQueue:
    def __init__(self):
        self.data = []
        self.front = 0  # Index of the front element
        self.rear = 0  # Index of the element after the last element

    def __len__(self):
        return self.rear - self.front

    def is_empty(self):
        return self.front == self.rear

    def enqueue(self, e):
        if self.rear >= len(self.data):  # Check if resize is needed
            self.data.extend([None] * (len(self.data) * 2 + 1))  # Double the size + 1
        self.data[self.rear] = e
        self.rear += 1

    def dequeue(self):
        if self.is_empty():
            raise Exception('Queue Underflow')
        removed_element = self.data[self.front]
        self.front += 1
        return removed_element

    def peek(self):
        if self.is_empty():
            raise Exception('Queue Underflow')
        return self.data[self.front]

    def __str__(self):
        if self.is_empty():
            return "Queue is empty"
        result = []
        for i in range(self.front, self.rear):
            result.append(self.data[i])
        return " front -> " + ", ".join(map(str, result)) + " <- rear"

# GUI Application
class QueueApp:
    def __init__(self, root):
        self.queue = ArrayQueue()

        self.root = root
        self.root.title("ArrayQueue GUI")

        self.label = tk.Label(root, text="ArrayQueue", font=("Helvetica", 16))
        self.label.pack(pady=10)

        self.queue_display = tk.Label(root, text=str(self.queue), font=("Helvetica", 12))
        self.queue_display.pack(pady=10)

        self.entry = tk.Entry(root, font=("Helvetica", 12))
        self.entry.pack(pady=5)

        self.enqueue_button = tk.Button(root, text="Enqueue", command=self.enqueue)
        self.enqueue_button.pack(pady=5)

        self.dequeue_button = tk.Button(root, text="Dequeue", command=self.dequeue)
        self.dequeue_button.pack(pady=5)

        self.peek_button = tk.Button(root, text="Peek", command=self.peek)
        self.peek_button.pack(pady=5)

    def update_display(self):
        self.queue_display.config(text=str(self.queue))

    def enqueue(self):
        element = self.entry.get()
        if element:
            self.queue.enqueue(element)
            self.entry.delete(0, tk.END)
            self.update_display()
        else:
            messagebox.showwarning("Input Error", "Please enter a value to enqueue.")

    def dequeue(self):
        try:
            element = self.queue.dequeue()
            messagebox.showinfo("Dequeued Element", f"Dequeued: {element}")
            self.update_display()
        except Exception as e:
            messagebox.showerror("Queue Underflow", str(e))

    def peek(self):
        try:
            element = self.queue.peek()
            messagebox.showinfo("Peek Element", f"Front element: {element}")
        except Exception as e:
            messagebox.showerror("Queue Underflow", str(e))

# Main function to run the GUI application
if __name__ == "__main__":
    root = tk.Tk()
    app = QueueApp(root)
    root.mainloop()