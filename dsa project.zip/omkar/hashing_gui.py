import tkinter as tk
from tkinter import messagebox

class HashTable:
    def __init__(self, size=10):
        self.size = size
        self.table = [[] for _ in range(size)]  # Use a list of lists for separate chaining

    def _ascii_hash_function(self, key):
        """Calculate hash function using the sum of ASCII values of the characters."""
        ascii_sum = sum(ord(char) for char in key)
        return ascii_sum % self.size  # Modulus with the size of the table

    def insert(self, key):
        """Insert key into the hash table."""
        index = self._ascii_hash_function(key)
        if key not in self.table[index]:
            self.table[index].append(key)

    def remove(self, key):
        """Remove key from the hash table."""
        index = self._ascii_hash_function(key)
        if key in self.table[index]:
            self.table[index].remove(key)

    def contains(self, key):
        """Check if the key exists in the hash table."""
        index = self._ascii_hash_function(key)
        return key in self.table[index]

    def display(self):
        """Return the current state of the hash table."""
        return self.table

    def hash_code(self, key):
        """Return the sum of ASCII values and the final hash code."""
        ascii_sum = sum(ord(char) for char in key)
        return ascii_sum, ascii_sum % self.size

class HashTableApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Hash Table with ASCII-Based Hashing")
        self.hash_table = HashTable()
        self.root.geometry("600x500")
        self.root.configure(bg="#f0f8ff")  # Light pastel background

        # Changed to grid
        self.labelOmkar = tk.Label(root, text="S088 Omkar Kubal", bg="#FFFAF0", font=("Arial", 18, "italic"))
        self.labelOmkar.grid(row=0, column=0, pady=5, columnspan=3)  # Use grid

        # Title label
        self.label = tk.Label(root, text="Hash Set", font=("Arial", 20, "bold"), bg="#f0f8ff", fg="#4b0082")
        self.label.grid(row=1, column=0, columnspan=3, pady=20)

        # Hash Set Display Area
        self.display_area = tk.Text(root, height=12, width=50, font=("Arial", 16), bg="#e0ffff")
        self.display_area.grid(row=2, column=0, columnspan=3, padx=20, pady=10)

        # Hash code label
        self.hash_code_label = tk.Label(root, text="Hash Code (ASCII Sum)", font=("Arial", 16, "bold"), bg="#f0f8ff")
        self.hash_code_label.grid(row=3, column=0, pady=20)

        # Hash code result
        self.hash_code_value = tk.Label(root, text="", font=("Arial", 16), fg="blue", bg="#f0f8ff")
        self.hash_code_value.grid(row=3, column=1, pady=20)

        # Input entry
        self.entry = tk.Entry(root, width=30, font=("Arial", 16))
        self.entry.grid(row=4, column=0, columnspan=2, pady=20)

        # Buttons for operations
        self.add_btn = tk.Button(root, text="Add", command=self.add, width=10, font=("Arial", 14), bg="#b0e0e6")
        self.add_btn.grid(row=5, column=0, padx=10, pady=10)

        self.remove_btn = tk.Button(root, text="Remove", command=self.remove, width=10, font=("Arial", 14), bg="#b0e0e6")
        self.remove_btn.grid(row=5, column=1, padx=10, pady=10)

        self.contains_btn = tk.Button(root, text="Contains", command=self.contains, width=10, font=("Arial", 14), bg="#b0e0e6")
        self.contains_btn.grid(row=6, column=0, padx=10, pady=10)

        self.size_btn = tk.Button(root, text="Size", command=self.size, width=10, font=("Arial", 14), bg="#b0e0e6")
        self.size_btn.grid(row=6, column=1, padx=10, pady=10)

        # Initial Display
        self.update_display()

    def update_display(self):
        """Update the hash set display area."""
        self.display_area.delete('1.0', tk.END)
        hash_table = self.hash_table.display()
        for i, bucket in enumerate(hash_table):
            if bucket:
                items = ' -> '.join(bucket)
                self.display_area.insert(tk.END, f"{i} : {items}\n")
            else:
                self.display_area.insert(tk.END, f"{i} :\n")

    def update_hash_code(self, key):
        """Display the ASCII sum and hash code of the input key."""
        ascii_sum, hash_code = self.hash_table.hash_code(key)
        self.hash_code_value.config(text=f"Sum of ASCII: {ascii_sum}, Hash Code: {ascii_sum} % {self.hash_table.size} = {hash_code}")

    def add(self):
        """Add a key to the hash table and update display."""
        key = self.entry.get().strip()
        if key:
            self.hash_table.insert(key)
            self.update_hash_code(key)
            self.update_display()
            self.entry.delete(0, tk.END)  # Clear the input field

    def remove(self):
        """Remove a key from the hash table and update display."""
        key = self.entry.get().strip()
        if key:
            self.hash_table.remove(key)
            self.update_hash_code(key)
            self.update_display()
            self.entry.delete(0, tk.END)  # Clear the input field

    def contains(self):
        """Check if a key is in the hash table."""
        key = self.entry.get().strip()
        if key:
            found = self.hash_table.contains(key)
            message = f"'{key}' is in the hash table." if found else f"'{key}' is not in the hash table."
            messagebox.showinfo("Result", message)
            self.update_hash_code(key)

    def size(self):
        """Display the total size (number of elements) of the hash table."""
        hash_table = self.hash_table.display()
        size = sum(len(bucket) for bucket in hash_table)
        messagebox.showinfo("Size", f"Hash table contains {size} elements.")

# Main Application
if __name__ == "__main__":
    root = tk.Tk()
    app = HashTableApp(root)
    root.mainloop()
